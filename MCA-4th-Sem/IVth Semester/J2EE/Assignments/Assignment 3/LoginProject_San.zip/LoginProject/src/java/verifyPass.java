import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet(urlPatterns = {"/verifyPass"})
public class verifyPass extends HttpServlet 
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Database DB=new Database();      
        String username = request.getParameter("uname");
        String password = request.getParameter("pwd");
        try
         {
            DB.query = "Select * from user_master";
            DB.result = DB.stmt.executeQuery(DB.query);
            int flag=0;
            while(DB.result.next())
            {
                String uname=DB.result.getString("username");
                String pass=DB.result.getString("password");
                if(uname.equals(username) && pass.equals(password))
                {
                    flag=1;
                    break;
                }
            }
            if(flag==0)
            {
                response.sendRedirect("http://localhost:8084/LoginProject/WrongPassword.html?flag=false/");
            }
            else
            {
                out.println("<h3>Student Detail</h3> ");
                out.println("<br/>");
                out.println("Username: "+DB.result.getString("username"));
                out.println("<br/>");
                out.println("Name: "+DB.result.getString("sname"));
                out.println("<br/>");
                out.println("Gender: "+DB.result.getString("sex"));
                out.println("<br/>");
                out.println("Aadhar No: "+DB.result.getString("aadhar"));
                out.println("<br/>");
                out.println("PanCard No: "+DB.result.getString("pan"));
                out.println("<br/>");
                out.println("Email-Id: "+DB.result.getString("email"));
                out.println("<br/>");
                out.println("Mobile: "+DB.result.getString("mobile"));
                out.println("<br/>");
                out.println("Course: "+DB.result.getString("course"));
                out.println("<br/>");
                out.println("Semester: "+DB.result.getString("semester"));
                out.println("<br/>");
                out.println("<p><a href='http://localhost:8084/LoginProject/'>LogOut</a></p>");
            }
         }
        catch(Exception e) 
        {
            out.println("unable to access database");
            out.print(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}