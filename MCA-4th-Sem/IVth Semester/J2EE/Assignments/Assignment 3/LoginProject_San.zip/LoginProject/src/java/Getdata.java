import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ucanaccess.jdbc.UcanaccessSQLException;

@WebServlet(urlPatterns = {"/Getdata"})
public class Getdata extends HttpServlet
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE HTML5>");
        out.println("<html>");
        out.println("<body>");        
        
    try{
        Database DB=new Database();
        DB.query="insert into user_master values('"
                +request.getParameter("username")+"','"
                +request.getParameter("password")+"','"
                +request.getParameter("name")+"','"
                +request.getParameter("gender")+"','"
                +request.getParameter("aadhar")+"','"
                +request.getParameter("pan")+"','"
                +request.getParameter("email")+"','"
                +request.getParameter("countrycode")+request.getParameter("mobile")+"','"
                +request.getParameter("course")+"','"
                +request.getParameter("semester")+"')";
                
            DB.stmt.executeUpdate(DB.query);
            out.println("<h>Form Submitted Successfully..</h>");
            ConnectionManager.putConnection(DB.connect);
        }
        catch (UcanaccessSQLException e) 
        {
            if(e.getErrorCode()==-104)
            {
                out.println("<h>Username already Exists. Please choose Different..</h><br>");
            }
            else
            {
                out.println("<h>"+e.getMessage()+"</h><br>");
            }
        }
        catch (SQLException e) {out.println("<h>"+e.getMessage()+"</h><br>");}
        finally
        {
            out.println("<br><br><h><a href=\"register.html\">Click here </a>to go Registration page</h>");
            out.println("<br><br><h4><a href=\"index.html\">Click here </a>to go Login page </h4>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}