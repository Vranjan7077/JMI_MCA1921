import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import net.ucanaccess.jdbc.UcanaccessSQLException;

@WebServlet(urlPatterns = {"/retrievepass"})
public class retrievepass extends HttpServlet 
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Database DB=new Database();
        ResultSet rs;
      
        String username = request.getParameter("username");
        String aadhar = request.getParameter("aadhar");
        String pan = request.getParameter("pan");
        try
         {
            DB.query="Select * from user_master";
            DB.result=DB.stmt.executeQuery(DB.query);
            int flag=0;
            String mypass="";
            if(aadhar!=null)
            {
                while(DB.result.next())
                {
                    String uname=DB.result.getString("username");
                    String aadhar1=DB.result.getString("aadhar");
                    if(uname.equals(username) && (aadhar.equals(aadhar1)))
                    {
                        flag=1;
                        mypass=DB.result.getString("password");
                        break;
                    }
                }
            }
            
            if(pan!=null)
            {
                while(DB.result.next())
                {
                    String uname=DB.result.getString("username");
                    String pan1=DB.result.getString("pan");
                    if(uname.equals(username) && pan.equals(pan1))
                    {
                        flag=1;
                        mypass=DB.result.getString("password");
                        break;
                    }
                }
            }
            
            if(flag==0)
            {
                response.sendRedirect("http://localhost:8084/LoginProject/WrongRetriveP.html?flag=false/");
                ConnectionManager.putConnection(DB.connect);
            }
            
            else
            {
                out.println("<h3>Your Password is :    " + mypass +"<h3>");
                out.println("<p class='message'><a href='http://localhost:8084/LoginProject/index.html'>Back To Login page</a></p>");
                ConnectionManager.putConnection(DB.connect);
            }
         }
        catch(Exception e) 
        {
            out.println("unable to access database");
            out.print(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
