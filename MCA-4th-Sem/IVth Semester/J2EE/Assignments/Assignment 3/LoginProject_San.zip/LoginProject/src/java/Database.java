import java.sql.*;

public class Database 
{
    public Connection connect;
    public Statement stmt;
    public String query;
    public ResultSet result;

    public Database() 
    {
        try
        {
            connect= ConnectionManager.getConnection();
            stmt=connect.createStatement();
        }catch (Exception e) {}
    }
}