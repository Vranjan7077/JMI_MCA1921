import java.sql.*;

public class Database 
{
    public Connection connect;
    public Statement stmt;
    public String query;
    public ResultSet result;

    public Database() 
    {
        try
        {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            connect= DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Sanjeev biswas\\Documents\\NetBeansProjects\\Registration\\src\\java\\XE.accdb","","");
            stmt=connect.createStatement();
        }catch (Exception e) {}
    }
}