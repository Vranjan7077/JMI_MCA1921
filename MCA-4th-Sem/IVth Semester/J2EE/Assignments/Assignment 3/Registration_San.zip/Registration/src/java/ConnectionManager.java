import java.sql.*;
import java.util.*;
 
class ConnectionManager
{  
	static Stack<Connection> ConnectionPool = new Stack<Connection>();
	static
	{
		try
		{
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			Connection con[] = new Connection[100];
			for(int i=0;i<100;i++)
			{
				con[i]=DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Sanjeev biswas\\Documents\\NetBeansProjects\\LoginProject\\src\\java\\XE.accdb","","");
				ConnectionPool.push(con[i]);
			}
		}
		catch(SQLException e)	{System.out.println(e);}
		catch(ClassNotFoundException e){}
	}
	
	static Connection getConnection()
	{
		return (ConnectionPool.pop());
	}
	
	static void putConnection(Connection dummy)
	{
		ConnectionPool.push(dummy);
	}
	
	static int availableConnection()
	{
		return ((int)ConnectionPool.size());
	}
}