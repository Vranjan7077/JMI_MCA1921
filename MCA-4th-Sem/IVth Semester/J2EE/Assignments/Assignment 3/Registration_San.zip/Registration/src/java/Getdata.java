import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ucanaccess.jdbc.UcanaccessSQLException;

@WebServlet(urlPatterns = {"/Getdata"})
public class Getdata extends HttpServlet
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE HTML5>");
        out.println("<html>");
        out.println("<body>");        
        
        try{
            Database DB=new Database();
            // <editor-fold defaultstate="collapsed" desc="Query Build_up.">
            DB.query="insert into user_master values('"
                +request.getParameter("username")+"','"
                +request.getParameter("password")+"','"
                +request.getParameter("name")+"','"
                +request.getParameter("fathername")+"','"
                +request.getParameter("mothername")+"','"
                +request.getParameter("gender")+"','"
                +request.getParameter("address")+"','"
                +request.getParameter("email")+"','"
                +request.getParameter("countrycode")+request.getParameter("mobile")+"','"
                +request.getParameter("course")+"','"
                +request.getParameter("semester")+"','"
                +request.getParameter("session")+"','"
                +request.getParameter("department")+"','"
                +request.getParameter("faculty")+"','"
                +request.getParameter("university")+"','";
                for(String s:request.getParameterValues("subject"))
                {
                    DB.query=DB.query+s+",";
                }                    
                DB.query=DB.query+"')";
            // </editor-fold>    
                
            DB.stmt.executeUpdate(DB.query);
            out.println("<h>Form Submitted Successfully..</h>");
            ConnectionManager.putConnection(DB.connect);
        }
        catch (UcanaccessSQLException e) 
        {
            if(e.getErrorCode()==-104)
            {
                out.println("<h>Username already Exists. Please choose Different..</h><br>");
            }
            else{out.println("<h>"+e.getMessage()+"hi"+"</h><br>");}
        }
        catch (Exception e) {out.println("<h>"+e+"rewret</h><br>");}
        finally
        {
            out.println("<br><br><h>Click here to go registration page <a href=\"index.html\">Registration</a></h>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>

}
